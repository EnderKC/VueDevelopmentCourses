interface ReturnModel {
    code: number;
    msg: string;
    data: any;
}

export default ReturnModel