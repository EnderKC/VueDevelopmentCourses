<template>
    显示用户信息
</template>
    
<script lang="ts" setup>

</script>